/**
 * 
 */
package net.shopin.redis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author kongming
 *
 */
public class RedisUtils {
	
	private static Logger logger = LoggerFactory.getLogger(RedisUtils.class);
	
	
	
	
	
	
	

}
