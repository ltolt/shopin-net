/**
 * 
 */
package net.shopin.util;

/**
 * @author kongming
 *
 */
public class HttpClientUtil {

	
	
	
}
