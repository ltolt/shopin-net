/**
 * 
 */
package net.shopin.redis;

/**
 * @author kongming
 *
 */
public class RedisWebTest extends JedisCommandTestBase{
	
	
	

}
