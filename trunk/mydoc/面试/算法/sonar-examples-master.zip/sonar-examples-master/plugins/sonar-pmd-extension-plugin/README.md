Usage
=====
* Build the plugin:

        mvn clean install
		
* Copy the plugin into SONARQUBE_HOME/extensions/plugin
* Restart your SonarQube server
* The custom PMD rules are now available