package org.codehaus.sonar.tests.simple;

import junit.framework.TestCase;


public class HelloTest extends TestCase {

  public void testRun() throws Exception {
    Hello.run();
  }

}
