public class Helloworld {

  public void helloWorld() {
    System.out.println("HelloWorld");
    System.exit(33);
  }
  
}
