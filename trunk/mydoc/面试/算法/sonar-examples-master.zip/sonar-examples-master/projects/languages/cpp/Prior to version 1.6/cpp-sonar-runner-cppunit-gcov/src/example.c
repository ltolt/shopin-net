int main(int argc) {
  if (argc == 0) {
    return 0;
  } else {
    return 1;
  }
}
