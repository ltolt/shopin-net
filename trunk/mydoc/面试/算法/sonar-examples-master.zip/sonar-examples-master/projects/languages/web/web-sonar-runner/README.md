This example demonstrates how to analyze Web projects with the SonarQube Runner.

Prerequisites
=============
* [SonarQube](http://www.sonarsource.org/downloads/) 3.0 or higher
* [SonarQube Runner](http://docs.codehaus.org/x/N4KxDQ) 2.0 or higher
* [SonarQube Web Plugin](http://docs.codehaus.org/display/SONAR/Web+Plugin) 1.2 or higher

Usage
=====
* Analyze the project with SonarQube using the SonarQube Runner:

        sonar-runner
