package org.codehaus.sonar.tests.simple;

import junit.framework.TestCase;


public class MultiRulesTest extends TestCase {

  public void testRun() throws Exception {
    MultiRules.run();
  }

}
