This example demonstrates how to analyze Drools projects with the SonarQube Runner.

Prerequisites
=============
* [SonarQube](http://www.sonarsource.org/downloads/) 3.0 or higher
* [SonarQube Runner](http://docs.codehaus.org/x/N4KxDQ) 2.0 or higher
* [SonarQube Drools Plugin](http://docs.codehaus.org/display/SONAR/Drools+Plugin) 0.2 or higher

Usage
=====
* Analyze it with SonarQube using the SonarQube Runner:

        sonar-runner
