lst = []
