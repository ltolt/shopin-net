This example demonstrates how to collect code coverage by unit tests and integration tests.
SonarQube aggregates these code coverage data to compute an overall code coverage.

Prerequisites
=============
* [SonarQube](http://www.sonarsource.org/downloads/) 3.6 or higher
* [SonarQube Java Plugin](http://docs.codehaus.org/x/KwChCw) 1.4 or higher
* [SonarQube Runner](http://docs.codehaus.org/x/N4KxDQ) 2.0 or higher

Usage
=====
* Analyze the project with SonarQube Runner:

        sonar-runner
