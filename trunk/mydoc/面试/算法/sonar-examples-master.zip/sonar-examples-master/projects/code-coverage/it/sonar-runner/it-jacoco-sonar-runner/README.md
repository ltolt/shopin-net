This example demonstrates how to add information on integration tests coverage for a Java project using JaCoCo and SonarQube Runner.

Prerequisites
=============
* [SonarQube](http://www.sonarsource.org/downloads/) 3.0 or higher
* [SonarQube Runner](http://docs.codehaus.org/x/N4KxDQ) 2.0 or higher

Usage
=====
* Analyze it with SonarQube using the SonarQube Runner:

        sonar-runner