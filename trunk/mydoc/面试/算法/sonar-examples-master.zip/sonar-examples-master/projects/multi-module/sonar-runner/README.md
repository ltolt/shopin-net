The best way to understand how SonarQube Runner 2.0+ works is to give a try to the examples following this order:
* /projects/languages/java/java-sonar-runner-simple
* java-sonar-runner-modules-same-structure
* java-sonar-runner-modules-different-structures
* java-sonar-runner-modules-own-configuration-file