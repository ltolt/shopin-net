public class One {
  public String foo() {
    return "foo";
  }
}
