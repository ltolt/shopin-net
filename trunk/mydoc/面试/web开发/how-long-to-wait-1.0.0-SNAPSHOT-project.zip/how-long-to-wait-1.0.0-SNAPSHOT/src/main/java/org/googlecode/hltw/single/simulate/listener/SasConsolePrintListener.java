package org.googlecode.hltw.single.simulate.listener;

import java.math.BigDecimal;
import java.text.MessageFormat;

/**
 * 
 * put every message to console print
 * 
 * @author chenjianjx
 * 
 */
public class SasConsolePrintListener implements SingleAppSimulateEventListener {
	private int requestCount;

	@Override
	public Object oneRequestDone(int index, int subBatchIndex, BigDecimal beginMilisIncluded, BigDecimal endMilisExcluded) {
		System.out.print("Request No." + formatIndex(index) + ": ");
		for (int i = 0; i < subBatchIndex; i++) {
			System.out.print(" ");
		}
		System.out.print(beginMilisIncluded + "ms - " + endMilisExcluded + "ms");
		System.out.println();
		return null;
	}

	private String formatIndex(int index) {
		int expectWordLength = (int) Math.log10(requestCount);
		int thisWordLength = (int) Math.log10(index);

		int diff = expectWordLength - thisWordLength;
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < diff; i++) {
			sb.append("0");
		}
		sb.append(index);

		return sb.toString();
	}

	@Override
	public Object end() {
		System.out.println("All Done");
		return null;
	}

	@Override
	public Object start(int requestCount, int servingThread) {
		this.requestCount = requestCount;
		System.out.println(MessageFormat.format("Starting to simulate. The server will serve {0} requests with {1} threads", requestCount, servingThread));
		return null;
	}

}
