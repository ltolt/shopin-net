package org.googlecode.hltw.single.config.server.rt;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.googlecode.hltw.util.math.function.SingleVariableFunction;

/**
 * rt = constant when servingThread <= maxThreadHealthy <br/>
 * rt = f(servingCount) when servingThread > maxThreadHealthy and servingThread
 * <= maxThreadExtreme, the value of f() is proportional to servingThread<br/>
 * rt = f(maxThreadExtreme) when servingThread > maxThreadExtreme <br/>
 * 
 * 
 * @author chenjianjx
 * 
 */
public class TypicalRtFunction implements ResponseTimeFunction {

	private BigDecimal rtHealthy;

	private SingleVariableFunction proportion;

	public TypicalRtFunction() {
		super();
	}

	public TypicalRtFunction(BigDecimal rtHealthy, SingleVariableFunction proportion) {
		super();
		this.rtHealthy = rtHealthy;
		this.proportion = proportion;
	}

	@Override
	public BigDecimal getResponseMilisPerRequest(int maxThreadHealthy, int maxThreadExtreme, int servingThread) {

		if (servingThread <= maxThreadHealthy) {
			return rtHealthy;
		}

		if (servingThread <= maxThreadExtreme) {
			return proportion.getValue(BigDecimal.valueOf(servingThread));
		}

		return proportion.getValue(BigDecimal.valueOf(maxThreadExtreme));
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
