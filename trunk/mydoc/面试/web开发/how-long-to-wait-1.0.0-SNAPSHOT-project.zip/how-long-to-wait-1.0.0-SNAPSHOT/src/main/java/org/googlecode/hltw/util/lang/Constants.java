package org.googlecode.hltw.util.lang;

import java.math.BigDecimal;

/**
 * 
 * @author chenjianjx
 * 
 */
public class Constants {

	public static final int NA_INT = -1;
	public static final BigDecimal NA_DEC = BigDecimal.valueOf(-1l);
}
