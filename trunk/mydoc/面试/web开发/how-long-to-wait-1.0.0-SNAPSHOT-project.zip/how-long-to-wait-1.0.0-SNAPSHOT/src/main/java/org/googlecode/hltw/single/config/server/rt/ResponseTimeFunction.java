package org.googlecode.hltw.single.config.server.rt;

import java.math.BigDecimal;

/**
 * 
 * decide how long is the response time depending on server-side thread counts
 * 
 * @author chenjianjx
 * 
 */
public interface ResponseTimeFunction {

	BigDecimal getResponseMilisPerRequest(int maxThreadHealthy, int maxThreadExtreme, int servingThread);
}
