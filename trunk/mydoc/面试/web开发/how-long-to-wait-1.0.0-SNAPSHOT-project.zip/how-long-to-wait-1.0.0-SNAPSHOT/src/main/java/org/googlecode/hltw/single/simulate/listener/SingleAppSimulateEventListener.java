package org.googlecode.hltw.single.simulate.listener;

import java.math.BigDecimal;

/**
 * listen to the events that simulator sends
 * 
 * @author chenjianjx
 * 
 */
public interface SingleAppSimulateEventListener {

	Object start(int requestCount, int servingThread);

	Object oneRequestDone(int index, int subBatchIndex, BigDecimal beginMilisIncluded, BigDecimal endMilisExcluded);

	Object end();

}
