package org.googlecode.hltwsample.single;

import java.math.BigDecimal;

import org.googlecode.hltw.single.config.server.SingleAppServerNature;
import org.googlecode.hltw.single.config.server.rt.ResponseTimeFunction;
import org.googlecode.hltw.single.config.server.rt.TypicalRtFunction;
import org.googlecode.hltw.single.result.SingleAppVisitResult;
import org.googlecode.hltw.single.simulate.SingleAppVisitSimulator;
import org.googlecode.hltw.single.simulate.listener.SasConsolePrintListener;
import org.googlecode.hltw.util.math.function.PowFunction;
import org.googlecode.hltwsample.single.util.SavResultPrinter;

/**
 * 
 * @author chenjianjx
 * 
 */
public class ShowCase {

	public static void main(String[] args) {

		SingleAppServerNature serverNature = new SingleAppServerNature(3, 3);
		ResponseTimeFunction responseTimeFunction = new TypicalRtFunction(BigDecimal.valueOf(1), new PowFunction(BigDecimal.valueOf(1)));
		serverNature.setResponseTimeFunction(responseTimeFunction);
		int clientConcurrency = 10;

		System.out.println("=============Result by Simulation============");
		SingleAppVisitSimulator simulator = new SingleAppVisitSimulator();
		simulator.setEventListener(new SasConsolePrintListener());
		SingleAppVisitResult resultSimulate = simulator.simulate(serverNature, clientConcurrency);
		SavResultPrinter.doPrint(resultSimulate);

		// System.out.println("=============Result by Formulation============");
		// SavResultPrinter.doPrint(new
		// SingleAppVisitFormula().calculate(serverNature, clientConcurrency));

	}

}
