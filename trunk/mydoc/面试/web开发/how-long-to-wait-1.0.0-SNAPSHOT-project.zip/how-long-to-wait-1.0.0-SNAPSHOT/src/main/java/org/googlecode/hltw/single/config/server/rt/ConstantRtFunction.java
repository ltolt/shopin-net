package org.googlecode.hltw.single.config.server.rt;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.googlecode.hltw.util.lang.Constants;

/**
 * Always a same response-time no matter how many serving threads are there
 * 
 * @author chenjianjx
 * 
 */
public class ConstantRtFunction implements ResponseTimeFunction {

	private BigDecimal rt = Constants.NA_DEC;

	public ConstantRtFunction() {
		super();
	}

	public ConstantRtFunction(BigDecimal rt) {
		super();
		this.rt = rt;
	}

	@Override
	public BigDecimal getResponseMilisPerRequest(int maxThreadHealthy, int maxThreadExtreme, int servingThread) {
		return rt;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
