package org.googlecode.hltw.util.math.function;

import java.math.BigDecimal;

/**
 * 
 * @author chenjianjx
 * 
 */
public interface SingleVariableFunction {

	BigDecimal getValue(BigDecimal variable);

}
