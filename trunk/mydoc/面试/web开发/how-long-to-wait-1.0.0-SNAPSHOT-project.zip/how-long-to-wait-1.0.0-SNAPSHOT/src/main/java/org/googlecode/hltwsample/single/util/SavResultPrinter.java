package org.googlecode.hltwsample.single.util;

import java.text.MessageFormat;

import org.googlecode.hltw.single.result.SingleAppVisitResult;

/**
 * 
 * @author chenjianjx
 * 
 */
public class SavResultPrinter {

	public static void doPrint(SingleAppVisitResult result) {
		pn("");
		pn("The total count of requests is {}", result.getRequestCount());
		pn("The batch ended in {} miliseconds", result.getOverallMilis());

		pn("");

		pn("The server spend {} miliseconds to handle all the requests",
				result.getResponseMilisSum());
		pn("It takes {} miliseconds for each request to get handled, excluding waiting ",
				result.getResponseMilisAvg());
		pn("The qps form servers perspective is {}", result.getQpsForServer());
		pn("");
		pn("It takes the clients {} miliseconds to get all requests handled, including waiting",
				result.getWaitResponseMilisSum());
		pn("It takes {} miliseconds to for each request to get handled, including waiting ",
				result.getWaitMilisAvg());
		pn("The qps form clients perspective is {}", result.getQpsForClient());

	}

	private static void pn(String pattern, Object... arguments) {
		pattern = pattern.replaceAll("\\{\\}", "{0, number,####.#########}");
		System.out.println(MessageFormat.format(pattern, arguments));
	}

}
