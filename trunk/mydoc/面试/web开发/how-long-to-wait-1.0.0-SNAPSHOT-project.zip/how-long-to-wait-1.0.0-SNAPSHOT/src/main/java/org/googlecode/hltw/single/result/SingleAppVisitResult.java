package org.googlecode.hltw.single.result;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.googlecode.hltw.util.lang.Constants;

/**
 * 
 * @author chenjianjx
 * 
 */
public class SingleAppVisitResult {

	/**
	 * the overall miliseconds (the moment all requests are handled - the moment
	 * the requests are submitted)
	 */
	private BigDecimal overallMilis = Constants.NA_DEC;

	/**
	 * the sum of all the requests' wait and response time (each = the moment a
	 * request is handled - the moment the requests are submitted
	 */
	private BigDecimal waitResponseMilisSum = Constants.NA_DEC;

	/**
	 * the total time used by server to handle requests; This number doesn't
	 * include any waiting time
	 */
	private BigDecimal responseMilisSum = Constants.NA_DEC;

	/**
	 * the number of requests
	 */
	private int requestCount = Constants.NA_INT;

	public int getRequestCount() {
		return requestCount;
	}

	public void setRequestCount(int requestCount) {
		this.requestCount = requestCount;
	}

	public BigDecimal getOverallMilis() {
		return overallMilis;
	}

	public void setOverallMilis(BigDecimal overallMilis) {
		this.overallMilis = overallMilis;
	}

	public BigDecimal getWaitResponseMilisSum() {
		return waitResponseMilisSum;
	}

	public void setWaitResponseMilisSum(BigDecimal waitMilisSum) {
		this.waitResponseMilisSum = waitMilisSum;
	}

	/**
	 * the average value of each request's wait time
	 * 
	 * @return
	 */
	public BigDecimal getWaitMilisAvg() {
		return doDivide(waitResponseMilisSum, BigDecimal.valueOf(requestCount));
	}

	/**
	 * the qps viewing from server's perspective
	 * 
	 * @return
	 */
	public BigDecimal getQpsForServer() {
		return doDivide(BigDecimal.valueOf(1000 * requestCount), responseMilisSum);
	}

	/**
	 * the qps viewing from server's perspective
	 * 
	 * @return
	 */
	public BigDecimal getQpsForClient() {
		return doDivide(BigDecimal.valueOf(1000 * requestCount), waitResponseMilisSum);

	}

	public BigDecimal getResponseMilisAvg() {
		return doDivide(responseMilisSum, BigDecimal.valueOf(requestCount));
	}
	public BigDecimal getResponseMilisSum() {
		return responseMilisSum;
	}

	public void setResponseMilisSum(BigDecimal responseMilisSum) {
		this.responseMilisSum = responseMilisSum;
	}
	
	private BigDecimal doDivide(BigDecimal dividend, BigDecimal divisor) {
		int idealScale = Math.max(dividend.scale(), divisor.scale()) + 1;
		int scale = Math.max(idealScale, 3);
		BigDecimal pro = dividend.divide(divisor, scale, RoundingMode.HALF_UP);
		return pro;
	}


	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
