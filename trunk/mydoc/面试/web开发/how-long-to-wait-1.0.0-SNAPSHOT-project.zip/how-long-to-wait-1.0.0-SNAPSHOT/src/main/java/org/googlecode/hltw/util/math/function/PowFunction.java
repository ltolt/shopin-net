package org.googlecode.hltw.util.math.function;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * 
 * @author chenjianjx
 * 
 */
public class PowFunction implements SingleVariableFunction {

	private BigDecimal index;

	public PowFunction() {
		super();
	}

	public PowFunction(BigDecimal index) {
		super();
		this.index = index;
	}

	@Override
	public BigDecimal getValue(BigDecimal x) {

		return BigDecimal.valueOf(Math.pow(x.doubleValue(), index.doubleValue()));
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
