package org.googlecode.hltw.single.config.server;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.googlecode.hltw.single.config.server.rt.ResponseTimeFunction;
import org.googlecode.hltw.util.lang.Constants;

/**
 * the performance nature of a server
 * 
 * @author chenjianjx
 * 
 */
public class SingleAppServerNature {

	/**
	 * the maximum serving threads as long as the server remains healthy
	 */
	private int maxThreadHealthy = Constants.NA_INT;

	/**
	 * the maximum serving threads the server can have, regardless of being
	 * healthy or not
	 */
	private int maxThreadExtreme = Constants.NA_INT;

	private ResponseTimeFunction responseTimeFunction;

	public SingleAppServerNature(int maxThreadHealthy, int maxThreadExtreme) {
		super();
		this.maxThreadHealthy = maxThreadHealthy;
		this.maxThreadExtreme = maxThreadExtreme;
	}

	/**
	 * the response time depending on how many threads are serving
	 * 
	 * @param servingThread
	 * @return
	 */
	public BigDecimal getResponseMilisPerRequest(int servingThread) {
		if (responseTimeFunction == null) {
			throw new IllegalArgumentException("You must have set the response-time-function");
		}
		return responseTimeFunction.getResponseMilisPerRequest(maxThreadHealthy, maxThreadExtreme, servingThread);
	}

	public int getMaxThreadHealthy() {
		return maxThreadHealthy;
	}

	public int getMaxThreadExtreme() {
		return maxThreadExtreme;
	}

	public void setResponseTimeFunction(ResponseTimeFunction responseTimeFunction) {
		this.responseTimeFunction = responseTimeFunction;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
